<!DOCTYPE html>
<html lang="de" dir="ltr">
  <head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
	<link rel="icon" href="http://localhost/demo/Homepage/PHP Login System/Main/img/AG_icon.webp">
	<link rel="stylesheet" type="text/css" href="http://localhost/demo/Homepage/PHP Login System/Main/vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="http://localhost/demo/Homepage/PHP Login System/Main/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="http://localhost/demo/Homepage/PHP Login System/Main/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
	<link rel="stylesheet" type="text/css" href="http://localhost/demo/Homepage/PHP Login System/Main/vendor/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="http://localhost/demo/Homepage/PHP Login System/Main/vendor/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="http://localhost/demo/Homepage/PHP Login System/Main/vendor/animsition/css/animsition.min.css">
	<link rel="stylesheet" type="text/css" href="http://localhost/demo/Homepage/PHP Login System/Main/vendor/select2/select2.min.css">
	<link rel="stylesheet" type="text/css" href="http://localhost/demo/Homepage/PHP Login System/Main/vendor/daterangepicker/daterangepicker.css">
	<link rel="stylesheet" type="text/css" href="http://localhost/demo/Homepage/PHP Login System/Main/css/util.css">
	<link rel="stylesheet" type="text/css" href="http://localhost/demo/Homepage/PHP Login System/Main/css/main.css">
	
	<script scr="http://localhost/demo/Homepage/PHP Login System/Main/popup.js" defer></script>
	<script src="http://localhost/demo/Homepage/PHP Login System/Main/vendor/jquery/jquery-3.2.1.min.js"></script>
	<script src="http://localhost/demo/Homepage/PHP Login System/Main/vendor/animsition/js/animsition.min.js"></script>
	<script src="http://localhost/demo/Homepage/PHP Login System/Main/vendor/bootstrap/js/popper.js"></script>
	<script src="http://localhost/demo/Homepage/PHP Login System/Main/vendor/bootstrap/js/bootstrap.min.js"></script>
	<script src="http://localhost/demo/Homepage/PHP Login System/Main/vendor/select2/select2.min.js"></script>
	<script src="http://localhost/demo/Homepage/PHP Login System/Main/vendor/daterangepicker/moment.min.js"></script>
	<script src="http://localhost/demo/Homepage/PHP Login System/Main/vendor/daterangepicker/daterangepicker.js"></script>
	<script src="http://localhost/demo/Homepage/PHP Login System/Main/vendor/countdowntime/countdowntime.js"></script>
	<script src="http://localhost/demo/Homepage/PHP Login System/Main/js/main.js"></script>
  </head>
  <body>
  <?php
  define('BASE_URL', 'http://localhost/demo/Homepage/PHP Login System/Main');
function redirect($path)
{
    header("Location: {$path}");
    exit;
}
?>
    <?php
    if(isset($_POST["submit"])){
      require("mysql.php");
      $stmt = $mysql->prepare("SELECT * FROM kunden WHERE login = :login"); //Login überprüfen
      $stmt->bindParam(":login", $_POST["login"]);
      $stmt->execute();
	  $stmt = $mysql->prepare("SELECT * FROM Codes WHERE Code = :Code"); //akt_Code überprüfen
      $stmt->bindParam(":Code", $_POST["Code"]);
	  $stmt->execute();
	  $stmt = $mysql->prepare("SELECT * FROM kunden WHERE company = :company"); //akt_Code überprüfen
      $stmt->bindParam(":company", $_POST["company"]);
      $stmt->execute();
      $count = $stmt->rowCount();
      if($count == 1){
        //Username ist frei
        $row = $stmt->fetch();
        if(password_verify($_POST["Password"], $row["Password"])){
          session_start();
          $_SESSION["login"] = $row["login"];
          redirect(BASE_URL.'/test.html');
        } else {
          echo "Der Loginversuch war fehlgeschlagen. Bitte überprüfen Sie Ihre Eingabedaten.";
        }
      } else {
        echo "Der Loginversuch war fehlgeschlagen. Bitte überprüfen Sie Ihre Eingabedaten.";
      }
    }
     ?>
	 <form action="index.php" method="post">
  <div class="limiter">
		<div class="container-login100" style="background-image: url('http://localhost/demo/Homepage/PHP Login System/Main/img/bg-01.jpg');">
			<div class="wrap-login100 p-t-30 p-b-50">
				<span class="login100-form-title p-b-41">
					Account Login
				</span>
				<form class="login100-form validate-form p-b-33 p-t-5">
				
				<div class="wrap-input100 validate-input"	>
						<input class="input100" type="text" name="company" placeholder="Firmenname" required>
							<span class="focus-input100" data-placeholder="&#xe82a;"></span>
					</div>
    
		<div class="wrap-input100 validate-input"	>
						<input class="input100" type="text" name="login" placeholder="Vor- und Nachname" required>
							<span class="focus-input100" data-placeholder="&#xe82a;"></span>
					</div>
	  
	  <div class="wrap-input100 validate-input">
						<input class="input100" type="password" name="Password" placeholder="Password" required>
						<span class="focus-input100" data-placeholder="&#xe80f"></span>
					</div>
					
					<div class="wrap-input100 validate-input">
					<input class="input100" type="text" name="Code" placeholder="Aktivierungscode" required>
					<span class="focus-input100" data-placeholder="&#xe80f"></span>
					</div>
					
	  <div class="container-login100-form-btn m-t-32">
					
						<button class="login100-form-btn" type="submit" name="submit">
						Anmelden
						</button>
						</form>
						
	<div class="container-login100-form-btn m-t-32">
    <a href="register.php"class="login100-form-btn">Noch keinen Account?</a>
	</div>
						</div>
					</form>
				</div>
			</div>
		</div>
   </body> 
</html>
