//Aleskej Gajic
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Scanner;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

	public class datenbank {
	private static Scanner input;
	public static void main(String[] args) {
	input = new Scanner(System.in);
	String companyName;
	int MonthlyTransactions, goodsSize, monthlyTurnover; // Initialisierung der Eingaben
	
	Map<Long, String> merchantCategory = new HashMap<Long, String>();
	
	merchantCategory.put((long) 199999, "Z Händler");
	merchantCategory.put((long) 499999, "D Händler");
	merchantCategory.put((long) 2499999, "C Händler");
	merchantCategory.put((long) 9999999, "B Händler");
	merchantCategory.put((long) 24999999, "B+ Händler");
	merchantCategory.put((long) 49999999, "A Händler");
	merchantCategory.put((long) 999999999, "A+ Händler");
	
	System.out.println("Bitte geben Sie Ihren vollen Firmennamen an (z.B. Mustermann GmbH)");
	companyName = input.nextLine();
	System.out.println("Geben Sie Ihre monatlichen Transaktionen an.");
	MonthlyTransactions = input.nextInt();
		
	if(MonthlyTransactions <= 0){
		System.err.println("[Errorcode: 0001] Bitte geben Sie einen höheren Wert als 0 ein, bei Ihren monatlichen Transaktionen an!"); // Wenn monatliche Transaktionen = 0, Error!.
		return;
	}
	
	System.out.println("Geben Sie ihre durchschnittliche Warenkorbgröße an (in Cents)");
	goodsSize = input.nextInt();
	
	if(goodsSize <= 0) {
		System.err.println("[Errorcode: 0002] Bitte geben Sie einen höheren Wert als 0 ein, bei Ihrer durchschnittlicher Warenkorbgroeße an!"); // Wenn durschnittliche Warenkorbgroeße = 0, Error!
		return;
	}
	
	monthlyTurnover = (MonthlyTransactions * goodsSize); // Berechnung des Monatlichenumsatzes
	long doublePayment = monthlyTurnover;
	NumberFormat n = NumberFormat.getCurrencyInstance(Locale.GERMANY);
	String s = n.format(doublePayment / 100.0);
	
	TreeMap<Long,String> sorted = new TreeMap<Long,String> (merchantCategory);
	
	for (Long turnover : sorted.keySet()) {
		String category = merchantCategory.get(turnover);
		if (monthlyTurnover <= turnover){
			System.out.println("Herzlich Wilkommen " + companyName + " (" + category + ") " + "[gesammter Umastz: "+s+" pro Monat]");
			break;
}
}
}
}